package org.myorg.war6.svc;

/**
 * This interface defines the business interface for the Hello Service.
 */
public interface HelloService {
	String sayHello(String name);
}
